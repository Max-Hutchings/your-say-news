# Handoff: "Your Say News" — Mobile App (3 screens)

## Overview
"Your Say News" is a tech-news mobile app (iOS + Android) built around one idea: readers
**vote agree/disagree** on short news *motions*, then unlock **aggregated, anonymous sentiment**
showing how different kinds of people split — "people like you vs people unlike you" — broken
down by demographic characteristics, **without ever exposing any individual's identity**.

This package covers three screens: **Login/Welcome**, a **5-step Characteristics onboarding wizard**,
and the **News Feed with the sentiment reveal**. Each is designed for both **light and dark** mode.

## About the design files
`Your Say News.dc.html` is a **design reference created in HTML** — a high-fidelity, partly-interactive
prototype showing intended look and behavior. **It is not production code to copy.** The task is to
**recreate these designs in the target codebase** (React Native / Expo with NativeWind/Tailwind, per the
brief) using its established components, navigation, and patterns. The file opens directly in a browser;
the left phone in each section is the interactive one (tap to vote, step the wizard, switch breakdowns).

> Tooling note: the `.dc.html` is a "Design Component" — markup + a small logic class. You only need to
> read it as a visual/behavioral spec. Don't try to port the DC runtime; reimplement in RN.

## Fidelity
**High-fidelity.** Colors, typography, spacing, radii and interactions are final. Recreate pixel-faithfully
using the codebase's libraries. Hex values, font names, and sizes below are authoritative.

---

## Design Tokens

### Color roles
| Role | Light | Dark |
|---|---|---|
| App background | `#E7E1D4` (gallery) / screen `#F6F1E7`, feed `#F1EBDD` | `#14110D` / feed `#100E0A` |
| Surface / card | `#FFFDF8` | `#1B1712` / `#1E1A15` |
| Card border | `#E0D8C8` / `#DCD4C4` | `#2E2920` / `#2A251E` |
| Primary text (ink) | `#1B1815` | `#F2ECDF` |
| Secondary text | `#5A564E` | `#A39A8A` |
| Muted / mono labels | `#9A9183` | `#7A7263` / `#8E8576` |
| **Brand signal (lime)** | `#C6FF4A` | `#C6FF4A` |
| **Agree (teal)** | `#157A63` | `#3FB592` |
| **Disagree (coral)** | `#D6402F` | `#FF6A57` |
| Track behind vote bars | `#EDE6D8` | `#2A251E` |
| "Case for" panel | bg `#EAF4EE`, border `#CFE3D6` | — |
| "Case against" panel | bg `#F8ECE9`, border `#EBCFC9` | — |
| Privacy note panel | bg `#EFF4DC`, border `#DDE7BD`, text `#4F6320` | bg `#1B231A`, border `#2C3A26`, text `#AFC97F` |

**Color rules:**
- **Lime is brand-only** — logo mark, primary CTA, the "YOU" badge, active tab indicator. Never used for vote data.
- **Teal = Agree, Coral = Disagree**, used consistently in every chart, everywhere.
- Never rely on color alone: every vote bar is paired with a `%` label and a text caption.

### Typography
Three families (all on Google Fonts):
- **Newsreader** (serif, weights 300–700, supports italic) — headlines, motions (italic), big numbers. Editorial voice.
- **Schibsted Grotesk** (weights 400–800) — all UI and body text.
- **Spline Sans Mono** (weights 400–600) — category tags, data labels, privacy notes, metadata, eyebrows.

Type scale used (px): display 42 / h1 32 / card headline 23–24 / sub-headline 18–21 / body 13.5–15 /
label 10–11 (mono, letter-spacing 0.12–0.16em, often UPPERCASE) / micro 9–10.
Headline letter-spacing ≈ -0.01 to -0.02em. Body line-height 1.45–1.55.

### Spacing / radius / motion
- 4pt base spacing scale.
- Radius language: **8 / 12 / 16** (chips & inputs ~11–14, cards 16–18, phone screen 40, vote bars 6–8).
- Motion: ease-out ~150–200ms for state changes; the sentiment reveal uses a `translateY(8px)→0` + fade
  ("ysnRise") over ~400ms. Vote bars can animate width/scaleX from 0 on reveal.
- Touch targets ≥ 44pt. Primary actions sit in the thumb zone (bottom of screen).

---

## Screens / Views

### 1. Login / Welcome
**Purpose:** brand first impression + one-tap SSO (no password form). 
**Layout:** full-screen column. Top: logo lockup (lime square "Y" + wordmark). Middle: editorial headline
("Nobody *agrees* on it. See who."), sub-copy, and a **locked teaser card** previewing a real split bar
("58% AGREE / 42% DISAGREE") with a lock hint. Bottom: a dark **SSO sheet** (rounded top corners) containing
the primary CTA and a secondary path.
**Key components:**
- **Primary SSO button:** full-width, height 54, radius 14, bg `#C6FF4A`, text `#1B1815`, weight 700, 16px,
  lock glyph + "Continue securely". This is the only primary action (SSO via identity provider / Keycloak).
- **Secondary button:** "Use a work or school account", height 48, transparent, 1px border `#3A352D`, text `#E7E1D4`.
- **Privacy line** (mono 10.5px, lime dot): "Anonymous by design — your name is never shown beside a vote."
- **Teaser card:** surface card, mono category eyebrow, serif quote, split bar, lock caption.

### 2. Characteristics Wizard (onboarding)
**Purpose:** collect demographic characteristics used ONLY for anonymous aggregation. ~5 steps.
**Real fields across the full flow:** location (country + city), age range, gender, sex at birth,
race/ethnicity (multi), country of birth, region/county, height & weight bands, income band, parent status,
eye colour, education level, occupation, university subject, and a **0–10 "how often do you follow the news?"** scale.
**Layout (every step):** sticky header (title "Set up your lens", "STEP n OF 5", 5-segment progress bar,
serif step title + sub-copy) → body (the step's input pattern) → **persistent privacy note** (green panel)
→ **sticky footer** with a square Back button + full-width dark Continue button (lime arrow). Final step
Continue reads "Finish setup".
**Input patterns (one per job):**
- **Selectable chips** — single-select (age, gender, sex) and multi-select (ethnicity, with an "N selected" counter).
  Chip: padding 11×15, radius 11, weight 600 14px, 1.5px border. Unselected `#FFFDF8`/border `#DCD4C4`/text `#3A352D`;
  selected bg `#1B1815`/text `#F6F1E7`.
- **Searchable select** for long lists (195 countries): text field with search icon, focus ring in teal,
  filtered result list with a checked selected row (`#22332B` highlight in dark), "N OF 195 MATCHES" caption.
- **Numeric scale (0–10)** for the news-habit question: a row of 11 tappable bars rising in height; bars ≤ value
  filled `#1B1815`, the selected bar outlined in lime; a big serif number + a word label (e.g. "News junkie");
  end captions "0 · HEADLINES ONLY" / "10 · ALL DAY".
- **Progress segments:** 5 equal bars; filled `#1B1815` (light) / `#C6FF4A` for current in dark.
**Privacy note (every step):** "Private. Only ever shown as anonymous aggregate — never tied to you."

### 3. News Feed + Sentiment Reveal (signature screen)
**Purpose:** browse recommended stories, vote on a clear **motion**, then see how demographic groups split.
**Layout:** sticky masthead (logo + wordmark + avatar; category filter chips: For you / AI / Policy / Hardware /
Climate) → scrollable feed of story cards → bottom **tab bar** (Feed / Discover / Pulse / You; active item has
lime accent).
**Story card — full anatomy (this is the core component):**
1. **Media** (optional): a 16:9 video thumbnail (play button overlay + duration pill "2:14" + "VIDEO · EXPLAINER"
   tag) OR a photo. A compact card variant puts a square photo thumbnail beside the text.
2. **Meta row:** mono category (coral/teal) + "N votes · 2h".
3. **Headline:** neutral news headline, serif 23px.
4. **Summary:** 2–3 sentence neutral summary, Schibsted 13.5px.
5. **THE MOTION box** (bg `#F4EFE3`, border `#E3DAC8`, radius 13): a "? YOU'RE VOTING ON THIS MOTION" mono label
   + the **exact proposition** in italic serif (e.g. *"Big Tech should be legally liable for AI-generated misinformation."*).
   This explicitly tells the user what Agree/Disagree means — separate from the news itself.
6. **Case For / Case Against:** two stacked panels — teal check ("THE CASE FOR" + one-line argument) and
   coral cross ("THE CASE AGAINST" + one-line argument). Informs the vote before casting it.
7. **Vote (pre-vote state):** mono prompt "DO YOU AGREE WITH THE MOTION?" + two buttons. Agree (teal-tinted) /
   Disagree (coral-tinted), height 50, radius 13, thumb-icons. Selected button fills solid with white text.
8. **Reveal (post-vote state, animates in):**
   - Confirmation row: "You voted AGREE/DISAGREE" (teal/coral) + legend (● Agree ● Disagree).
   - "HOW PEOPLE SPLIT" section.
   - **Two hero rows stacked** so the gap is the story: **"People like you"** (with lime "YOU" badge) and
     **"People unlike you"**, each a teal/coral split bar (height 17, radius 8) + `%` agree label.
   - **Breakdown switcher:** mono "BREAK DOWN BY" + chips **Politics / Age / Region** (active chip = ink/lime).
     Switching re-slices the same story into per-group split bars (height 11) live, without leaving the card.
   - **Privacy receipt** closes every reveal: "12,481 anonymous votes · no identity stored".

---

## Interactions & Behavior
- **Login:** primary button triggers SSO (identity provider, e.g. Keycloak) — a redirect/native auth, NOT an
  in-app email/password form. Secondary button = alternate SSO path.
- **Wizard:** Continue advances step (clamped 1→5), Back decrements (disabled/40% opacity on step 1). Progress
  segments fill up to current step. Chips toggle; multi-select updates the "N selected" counter. The 0–10 scale
  updates the number + word label on tap. Footer is sticky; body scrolls if needed.
- **Feed vote:** tapping Agree or Disagree sets the vote, then the card swaps the pre-vote block for the reveal
  (fade + 8px rise, ~400ms). Breakdown chips swap the per-group dataset instantly (~150ms).
- **Filter chips** in the masthead switch the feed category (active = ink fill).

## State Management
- **Wizard:** `step` (1–5) + one value per field (`country`, `city`, `age`, `gender`, `sex`,
  `ethnicity[]`, …, `news` 0–10). Derived: progress fill, "N selected" count, news word label.
- **Feed card:** per-story `vote` (`null | 'agree' | 'disagree'`) and `breakdownDim`
  (`'Politics' | 'Age' | 'Region'`). Reveal is shown when `vote !== null`. Sentiment datasets are keyed by
  dimension → list of `{ group, agreePct }`; "like you / unlike you" are two summary rows.
- Real implementation: fetch story list + per-story aggregate sentiment; POST the vote; never store or display
  any per-user identity alongside a vote.

## Assets
- **Fonts:** Newsreader, Schibsted Grotesk, Spline Sans Mono (Google Fonts). Load equivalents in RN
  (expo-google-fonts has all three).
- **Icons:** simple inline SVGs (lock, search, chevrons, thumbs, check/cross, tab glyphs) — replace with the
  codebase's icon set.
- **Media:** the video/photo areas are **striped placeholders** labelled "VIDEO · EXPLAINER" / "PHOTO" —
  swap for real media components. No proprietary imagery is used.

## Files
- `Your Say News.dc.html` — the full prototype (design-system summary header + all three screens, light + dark,
  with the interactive login teaser, wizard stepper, and feed vote→reveal). Open in a browser to interact.
